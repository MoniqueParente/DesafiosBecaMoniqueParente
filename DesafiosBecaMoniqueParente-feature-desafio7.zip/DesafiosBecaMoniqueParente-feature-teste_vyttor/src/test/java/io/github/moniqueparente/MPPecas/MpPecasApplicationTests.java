package io.github.moniqueparente.MPPecas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MpPecasApplicationTests {

	@Test
	void contextLoads() {
	}

}
