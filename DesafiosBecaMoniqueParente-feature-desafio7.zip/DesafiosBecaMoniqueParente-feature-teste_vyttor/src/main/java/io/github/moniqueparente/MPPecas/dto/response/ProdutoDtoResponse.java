package io.github.moniqueparente.MPPecas.dto.response;

import lombok.Data;

@Data
public class ProdutoDtoResponse{

    private String nome;
    private String marca;
}
