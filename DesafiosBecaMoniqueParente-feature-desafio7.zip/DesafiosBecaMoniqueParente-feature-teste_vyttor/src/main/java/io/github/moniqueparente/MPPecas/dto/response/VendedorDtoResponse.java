package io.github.moniqueparente.MPPecas.dto.response;

import lombok.Data;

@Data
public class VendedorDtoResponse {

    private String nome;
}
