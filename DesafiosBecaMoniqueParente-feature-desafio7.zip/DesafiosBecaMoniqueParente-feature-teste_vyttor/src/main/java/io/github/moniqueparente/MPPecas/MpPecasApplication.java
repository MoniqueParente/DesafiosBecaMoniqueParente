package io.github.moniqueparente.MPPecas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpPecasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MpPecasApplication.class, args);

	}
}
