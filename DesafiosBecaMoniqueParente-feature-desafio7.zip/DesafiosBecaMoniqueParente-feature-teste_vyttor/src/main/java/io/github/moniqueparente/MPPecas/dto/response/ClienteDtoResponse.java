package io.github.moniqueparente.MPPecas.dto.response;

import lombok.Data;

@Data
public class ClienteDtoResponse{

    private String nome;
    private String cpf;

}
